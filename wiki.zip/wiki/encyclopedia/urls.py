from django.urls import path

from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("search", views.search, name="search"),
    path("new-page", views.create_new_page,name= "create new page"),
    path("random-page",views.random_page, name="Random Page"),
    path("<str:title>", views.display_content, name="Encyclopedia Entry Content Page"),  
]
