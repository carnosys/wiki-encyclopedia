from django.shortcuts import render, redirect
from django.http import HttpResponse
import markdown2
from django import forms
import os
import random

from . import util


class newForm(forms.Form):
   q = forms.CharField()

class contentForm(forms.Form):
   title = forms.CharField()
   content = forms.CharField(widget=forms.Textarea)  
   editing = forms.HiddenInput() 

def index(request):
    return render(request, "encyclopedia/index.html", {
        "entries": util.list_entries()
    })

def display_content(request, title):
    content = util.get_entry(title)
    
    if content:
      content = markdown2.markdown(content)
    
    return render(request, "encyclopedia/encyclopedia.html",
                  {
                      "title": title,
                       "content": content
                      
                  })



def search(request):
   if request.method == "GET":
     form = newForm(request.GET)
     if form.is_valid():
        query = form.cleaned_data["q"]
        available_titles = util.list_entries()
        if query in available_titles:
           return redirect(display_content,title=query)
        else:
           results = []
           for title in available_titles:
              if query.lower() in title.lower():
                 results.append(title)
           return render(request, "encyclopedia/searchResult.html", 
                         {
                            "title":query,
                            "results":results
                         }
                         )            
              
   else:
      return HttpResponse("Invalid Form method of submission")
   
def create_new_page(request):
    if request.method == "POST":  
     form = contentForm(request.POST)
     if form.is_valid():
        title = form.cleaned_data["title"]
        content = form.cleaned_data["content"]
        editing = True if 'editing' in request.POST else False
        
        is_existing = True if util.get_entry(title) is not None else False
        
        
        if not editing and is_existing:
           return HttpResponse("The title already exists!!!")
        
        else:
           util.save_entry(title, content)


           if is_existing:
            return redirect('Encyclopedia Entry Content Page',title=title)
          
        
           else:
            return redirect('create new page')
           
    else:
       if "title" in request.GET and "content" in request.GET:
          editing = True
          initial_param={
             'title':request.GET.get('title'),
             'content':request.GET.get('content'),
          }
          form = contentForm(initial=initial_param)
          
       else:
          editing = False   
          form=contentForm() 

       return render(request,"encyclopedia/newpage.html", {
          'form' : form,
          'editing':editing
       })    
    

def random_page(request):
   list_of_entries = util.list_entries()
   title = random.choice(list_of_entries)
   return redirect('Encyclopedia Entry Content Page',title=title)